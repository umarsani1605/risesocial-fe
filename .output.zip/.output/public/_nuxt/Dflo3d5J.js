import{c as i}from"./bRKmu4jq.js";import{_ as c}from"./60e1r2ke.js";import{u}from"./LqNRd2IG.js";import{c as d}from"./C9FlcUF-.js";import{e as p,g as f,o as m,w as z,r as v,b as h,a as k,u as a,z as C}from"./CoPa1YT7.js";/**
 * @license lucide-vue-next v0.510.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y=d("arrow-left",[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]]);/**
 * @license lucide-vue-next v0.510.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const b=d("arrow-right",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]),g=p({__name:"CarouselNext",props:{variant:{default:"outline"},size:{default:"icon"},class:{}},setup(t){const o=t,{orientation:r,canScrollNext:l,scrollNext:n}=u();return(s,e)=>(m(),f(a(c),{"data-slot":"carousel-next",disabled:!a(l),class:C(a(i)("absolute size-8 rounded-full",a(r)==="horizontal"?"top-1/2 -right-12 -translate-y-1/2":"-bottom-12 left-1/2 -translate-x-1/2 rotate-90",o.class)),variant:s.variant,size:s.size,onClick:a(n)},{default:z(()=>[v(s.$slots,"default",{},()=>[h(a(b)),e[0]||(e[0]=k("span",{class:"sr-only"},"Next Slide",-1))])]),_:3},8,["disabled","class","variant","size","onClick"]))}}),P=p({__name:"CarouselPrevious",props:{variant:{default:"outline"},size:{default:"icon"},class:{}},setup(t){const o=t,{orientation:r,canScrollPrev:l,scrollPrev:n}=u();return(s,e)=>(m(),f(a(c),{"data-slot":"carousel-previous",disabled:!a(l),class:C(a(i)("absolute size-8 rounded-full",a(r)==="horizontal"?"top-1/2 -left-12 -translate-y-1/2":"-top-12 left-1/2 -translate-x-1/2 rotate-90",o.class)),variant:s.variant,size:s.size,onClick:a(n)},{default:z(()=>[v(s.$slots,"default",{},()=>[h(a(y)),e[0]||(e[0]=k("span",{class:"sr-only"},"Previous Slide",-1))])]),_:3},8,["disabled","class","variant","size","onClick"]))}});export{P as _,g as a};
