import{a as l,i as s}from"./CtH4V8ap.js";function t(i,r){return l(i)?!1:Array.isArray(i)?i.some(a=>s(a,r)):s(i,r)}export{t as i};
